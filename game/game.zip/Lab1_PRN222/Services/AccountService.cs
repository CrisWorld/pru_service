﻿using BusinessObjects.Model;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class AccountService : IAccountService
    {
        private readonly IAccountRepositoy _accountRepository;
        public AccountService(IAccountRepositoy accountRepository)
        {
            _accountRepository = accountRepository ?? new AccountRepository();
        }

        public AccountMember GetAccountByEmailPassword(string email, string password)
        {
            return _accountRepository.GetAccountByEmailPassword(email, password);
        }

        public AccountMember GetAccountbyId(int accountID)
        {
            return _accountRepository.GetAccountbyId(accountID);
        }
    }
}
