﻿using BusinessObjects.Model;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository ?? new ProductRepository();
        }

        public void DeleteProduct(Products p)
        {
            _productRepository.DeleteProduct(p);
        }

        public Products GetProductById(int id)
        {
            return  _productRepository.GetProductById(id);
        }

        public List<Products> GetProducts()
        {
            return _productRepository.GetProducts();
        }

        public void SaveProduct(Products p)
        {
            _productRepository.SaveProduct(p);
        }

        public void UpdateProduct(Products p)
        {
            _productRepository.UpdateProduct(p);
        }
    }
}
