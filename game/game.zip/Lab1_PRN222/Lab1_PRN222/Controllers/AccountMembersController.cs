﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BusinessObjects;
using BusinessObjects.Model;
using Services;

namespace Lab1_PRN222.Controllers
{
    public class AccountMembersController : Controller
    {
        private readonly IAccountService _accountService;

        public AccountMembersController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(AccountMember model)
        {
            if (ModelState.IsValid)
            {
                var user = _accountService.GetAccountByEmailPassword(model.EmailAddress, model.MemmberPassword);

                if (user != null)
                {
                    // Store user information in session
                    HttpContext.Session.SetString("UserId", user.MemberID.ToString());
                    HttpContext.Session.SetString("Username", user.FullName);

                    return RedirectToAction("Index", "Products"); // Redirect to home page
                }
                else
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
            }

            return View(model);
        }

    }
}
