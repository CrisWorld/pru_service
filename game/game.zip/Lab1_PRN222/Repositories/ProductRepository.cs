﻿using BusinessObjects.Model;
using DataAccessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class ProductRepository : IProductRepository
    {
        public void DeleteProduct(Products p) => ProductDAO.DeleteProduct(p);

        public Products GetProductById(int id) => ProductDAO.GetProductById(id);

        public List<Products> GetProducts() => ProductDAO.GetProducts();

        public void SaveProduct(Products p) => ProductDAO.SaveProduct(p);

        public void UpdateProduct(Products p) => ProductDAO.UpdateProduct(p);
    }
}
