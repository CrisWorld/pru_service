﻿using BusinessObjects.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public interface IAccountRepositoy
    {
        AccountMember GetAccountbyId(int accountID);

        AccountMember GetAccountByEmailPassword(string email, string password);
    }
}
