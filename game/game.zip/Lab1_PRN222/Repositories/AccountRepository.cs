﻿using BusinessObjects.Model;
using DataAccessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class AccountRepository : IAccountRepositoy
    {
        public AccountMember GetAccountByEmailPassword(string email, string password) => AccountDAO.GetAccountByEmailPassword(email, password);

        public AccountMember GetAccountbyId(int accountID) => AccountDAO.GetAccountById(accountID);
    }
}
