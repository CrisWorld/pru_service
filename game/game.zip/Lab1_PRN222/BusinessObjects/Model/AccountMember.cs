﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects.Model
{
    [PrimaryKey(nameof(MemberID))]
    public class AccountMember
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int MemberID { get; set; }

        public string? MemmberPassword { get; set; }

        public string? FullName { get; set; }

        public string? EmailAddress { get; set; }

        public int? MemberRole { get; set; }
    }
}
