﻿using BusinessObjects.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public class MyStoreContext : DbContext
    {
        public MyStoreContext()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", true, true)
                    .Build();
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("WebApp"));
            }
        }

        public virtual DbSet<AccountMember> AccountMembers { get; set; }

        public virtual DbSet<Categories> Categories { get; set; }

        public virtual DbSet<Products> Products { get; set; }
    }
}
