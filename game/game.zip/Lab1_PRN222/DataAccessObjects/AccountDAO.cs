﻿using BusinessObjects.Model;
using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessObjects
{
    public class AccountDAO
    {
        public static AccountMember GetAccountById(int accountID)
        {
            using var db = new MyStoreContext();
            return db.AccountMembers.FirstOrDefault(c => c.MemberID == accountID);
        }

        public static AccountMember GetAccountByEmailPassword(string email, string password)
        {
            using var db = new MyStoreContext();
            return db.AccountMembers.FirstOrDefault(c => c.EmailAddress.Equals(email) && c.MemmberPassword.Equals(password));
        }
    }
}
